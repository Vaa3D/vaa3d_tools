#ifndef vcl_iso_iosfwd_h_
#define vcl_iso_iosfwd_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <iosfwd>

#ifdef vcl_generic_iosfwd_STD
  ** error **
#else
# define vcl_generic_iosfwd_STD std
#endif

#include "../generic/vcl_iosfwd.h"

#endif // vcl_iso_iosfwd_h_
