#ifndef vcl_iso_ctime_h_
#define vcl_iso_ctime_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <ctime>

#ifdef vcl_generic_ctime_STD
  ** error **
#else
# define vcl_generic_ctime_STD std
#endif

#include "../generic/vcl_ctime.h"

#endif // vcl_iso_ctime_h_
