#ifndef vcl_iso_climits_h_
#define vcl_iso_climits_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <climits>

#ifdef vcl_generic_climits_STD
  ** error **
#else
# define vcl_generic_climits_STD std
#endif

#include "../generic/vcl_climits.h"

#endif // vcl_iso_climits_h_
