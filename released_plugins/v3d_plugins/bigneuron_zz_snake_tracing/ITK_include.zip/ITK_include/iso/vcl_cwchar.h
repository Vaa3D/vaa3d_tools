#ifndef vcl_iso_cwchar_h_
#define vcl_iso_cwchar_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <cwchar>

#ifdef vcl_generic_cwchar_STD
  ** error **
#else
# define vcl_generic_cwchar_STD std
#endif

#include "../generic/vcl_cwchar.h"

#endif // vcl_iso_cwchar_h_
