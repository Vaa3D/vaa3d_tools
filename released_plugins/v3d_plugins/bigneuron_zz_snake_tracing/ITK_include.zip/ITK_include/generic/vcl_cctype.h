#ifndef vcl_generic_cctype_h_
#define vcl_generic_cctype_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_cctype.hhh and run make

// isalnum
#ifndef vcl_isalnum
#define vcl_isalnum vcl_generic_cctype_STD :: isalnum
#endif
// isdigit
#ifndef vcl_isdigit
#define vcl_isdigit vcl_generic_cctype_STD :: isdigit
#endif
// isprint
#ifndef vcl_isprint
#define vcl_isprint vcl_generic_cctype_STD :: isprint
#endif
// isupper
#ifndef vcl_isupper
#define vcl_isupper vcl_generic_cctype_STD :: isupper
#endif
// tolower
#ifndef vcl_tolower
#define vcl_tolower vcl_generic_cctype_STD :: tolower
#endif
// isalpha
#ifndef vcl_isalpha
#define vcl_isalpha vcl_generic_cctype_STD :: isalpha
#endif
// isgraph
#ifndef vcl_isgraph
#define vcl_isgraph vcl_generic_cctype_STD :: isgraph
#endif
// ispunct
#ifndef vcl_ispunct
#define vcl_ispunct vcl_generic_cctype_STD :: ispunct
#endif
// isxdigit
#ifndef vcl_isxdigit
#define vcl_isxdigit vcl_generic_cctype_STD :: isxdigit
#endif
// toupper
#ifndef vcl_toupper
#define vcl_toupper vcl_generic_cctype_STD :: toupper
#endif
// iscntrl
#ifndef vcl_iscntrl
#define vcl_iscntrl vcl_generic_cctype_STD :: iscntrl
#endif
// islower
#ifndef vcl_islower
#define vcl_islower vcl_generic_cctype_STD :: islower
#endif
// isspace
#ifndef vcl_isspace
#define vcl_isspace vcl_generic_cctype_STD :: isspace
#endif

#endif // vcl_generic_cctype_h_
