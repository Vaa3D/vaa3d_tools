#ifndef vcl_generic_set_h_
#define vcl_generic_set_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_set.hhh and run make

// set
#ifndef vcl_set
#define vcl_set vcl_generic_set_STD :: set
#endif
// multiset
#ifndef vcl_multiset
#define vcl_multiset vcl_generic_set_STD :: multiset
#endif
// swap
#ifndef vcl_swap
#define vcl_swap vcl_generic_set_STD :: swap
#endif

#endif // vcl_generic_set_h_
