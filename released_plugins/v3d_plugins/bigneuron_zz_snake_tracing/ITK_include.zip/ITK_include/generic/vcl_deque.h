#ifndef vcl_generic_deque_h_
#define vcl_generic_deque_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_deque.hhh and run make

// deque
#ifndef vcl_deque
#define vcl_deque vcl_generic_deque_STD :: deque
#endif
// swap
#ifndef vcl_swap
#define vcl_swap vcl_generic_deque_STD :: swap
#endif

#endif // vcl_generic_deque_h_
