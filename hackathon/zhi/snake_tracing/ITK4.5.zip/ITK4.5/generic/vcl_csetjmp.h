#ifndef vcl_generic_csetjmp_h_
#define vcl_generic_csetjmp_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_csetjmp.hhh and run make

// jmp_buf
#ifndef vcl_jmp_buf
#define vcl_jmp_buf vcl_generic_csetjmp_STD :: jmp_buf
#endif
// longjmp
#ifndef vcl_longjmp
#define vcl_longjmp vcl_generic_csetjmp_STD :: longjmp
#endif

#endif // vcl_generic_csetjmp_h_
