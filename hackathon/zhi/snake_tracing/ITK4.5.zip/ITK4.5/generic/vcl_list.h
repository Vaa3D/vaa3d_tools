#ifndef vcl_generic_list_h_
#define vcl_generic_list_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_list.hhh and run make

// list
#ifndef vcl_list
#define vcl_list vcl_generic_list_STD :: list
#endif
// swap
#ifndef vcl_swap
#define vcl_swap vcl_generic_list_STD :: swap
#endif

#endif // vcl_generic_list_h_
