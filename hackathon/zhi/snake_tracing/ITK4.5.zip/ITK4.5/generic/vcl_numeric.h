#ifndef vcl_generic_numeric_h_
#define vcl_generic_numeric_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_numeric.hhh and run make

// accumulate
#ifndef vcl_accumulate
#define vcl_accumulate vcl_generic_numeric_STD :: accumulate
#endif
// inner_product
#ifndef vcl_inner_product
#define vcl_inner_product vcl_generic_numeric_STD :: inner_product
#endif
// partial_sum
#ifndef vcl_partial_sum
#define vcl_partial_sum vcl_generic_numeric_STD :: partial_sum
#endif
// adjacent_difference
#ifndef vcl_adjacent_difference
#define vcl_adjacent_difference vcl_generic_numeric_STD :: adjacent_difference
#endif

#endif // vcl_generic_numeric_h_
