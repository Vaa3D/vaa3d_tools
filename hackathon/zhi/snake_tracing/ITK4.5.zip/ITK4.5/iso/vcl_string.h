#ifndef vcl_iso_string_h_
#define vcl_iso_string_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <string>

#ifdef vcl_generic_string_STD
  ** error **
#else
# define vcl_generic_string_STD std
#endif

#include "../generic/vcl_string.h"

#endif // vcl_iso_string_h_
