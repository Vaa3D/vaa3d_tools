#ifndef vcl_iso_sstream_h_
#define vcl_iso_sstream_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <sstream>

#ifdef vcl_generic_sstream_STD
  ** error **
#else
# define vcl_generic_sstream_STD std
#endif

#include "../generic/vcl_sstream.h"

#endif // vcl_iso_sstream_h_
