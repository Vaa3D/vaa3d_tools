#ifndef vcl_iso_locale_h_
#define vcl_iso_locale_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <locale>

#ifdef vcl_generic_locale_STD
  ** error **
#else
# define vcl_generic_locale_STD std
#endif

#include "../generic/vcl_locale.h"

#endif // vcl_iso_locale_h_
