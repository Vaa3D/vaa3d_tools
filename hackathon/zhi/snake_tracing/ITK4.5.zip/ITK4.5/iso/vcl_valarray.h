#ifndef vcl_iso_valarray_h_
#define vcl_iso_valarray_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <valarray>

#ifdef vcl_generic_valarray_STD
  ** error **
#else
# define vcl_generic_valarray_STD std
#endif

#include "../generic/vcl_valarray.h"

#endif // vcl_iso_valarray_h_
