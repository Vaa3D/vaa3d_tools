#ifndef vcl_iso_vector_h_
#define vcl_iso_vector_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <vector>

#ifdef vcl_generic_vector_STD
  ** error **
#else
# define vcl_generic_vector_STD std
#endif

#include "../generic/vcl_vector.h"

#endif // vcl_iso_vector_h_
