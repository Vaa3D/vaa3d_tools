#ifndef vcl_iso_cwctype_h_
#define vcl_iso_cwctype_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <cwctype>

#ifdef vcl_generic_cwctype_STD
  ** error **
#else
# define vcl_generic_cwctype_STD std
#endif

#include "../generic/vcl_cwctype.h"

#endif // vcl_iso_cwctype_h_
