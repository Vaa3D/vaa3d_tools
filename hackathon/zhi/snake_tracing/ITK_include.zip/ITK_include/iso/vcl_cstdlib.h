#ifndef vcl_iso_cstdlib_h_
#define vcl_iso_cstdlib_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <cstdlib>

#ifdef vcl_generic_cstdlib_STD
  ** error **
#else
# define vcl_generic_cstdlib_STD std
#endif

#include "../generic/vcl_cstdlib.h"

#endif // vcl_iso_cstdlib_h_
