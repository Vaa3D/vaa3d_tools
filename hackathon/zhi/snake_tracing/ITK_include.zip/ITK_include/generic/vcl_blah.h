#ifndef vcl_generic_blah_h_
#define vcl_generic_blah_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_blah.hhh and run make

// blah
#ifndef vcl_blah
#define vcl_blah vcl_generic_blah_STD :: blah
#endif

#endif // vcl_generic_blah_h_
