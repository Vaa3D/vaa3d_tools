#ifndef vcl_generic_string_h_
#define vcl_generic_string_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_string.hhh and run make

// char_traits
#ifndef vcl_char_traits
#define vcl_char_traits vcl_generic_string_STD :: char_traits
#endif
// basic_string
#ifndef vcl_basic_string
#define vcl_basic_string vcl_generic_string_STD :: basic_string
#endif
// string
#ifndef vcl_string
#define vcl_string vcl_generic_string_STD :: string
#endif
// wstring
#ifndef vcl_wstring
#define vcl_wstring vcl_generic_string_STD :: wstring
#endif
// swap
#ifndef vcl_swap
#define vcl_swap vcl_generic_string_STD :: swap
#endif
// getline
#ifndef vcl_getline
#define vcl_getline vcl_generic_string_STD :: getline
#endif

#endif // vcl_generic_string_h_
