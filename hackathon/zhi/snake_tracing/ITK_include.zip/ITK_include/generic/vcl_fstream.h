#ifndef vcl_generic_fstream_h_
#define vcl_generic_fstream_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_fstream.hhh and run make

// filebuf
#ifndef vcl_filebuf
#define vcl_filebuf vcl_generic_fstream_STD :: filebuf
#endif
// fstream
#ifndef vcl_fstream
#define vcl_fstream vcl_generic_fstream_STD :: fstream
#endif
// ifstream
#ifndef vcl_ifstream
#define vcl_ifstream vcl_generic_fstream_STD :: ifstream
#endif
// ofstream
#ifndef vcl_ofstream
#define vcl_ofstream vcl_generic_fstream_STD :: ofstream
#endif

#endif // vcl_generic_fstream_h_
