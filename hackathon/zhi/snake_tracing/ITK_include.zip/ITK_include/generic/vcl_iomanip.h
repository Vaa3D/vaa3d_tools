#ifndef vcl_generic_iomanip_h_
#define vcl_generic_iomanip_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_iomanip.hhh and run make

// resetiosflags
#ifndef vcl_resetiosflags
#define vcl_resetiosflags vcl_generic_iomanip_STD :: resetiosflags
#endif
// setiosflags
#ifndef vcl_setiosflags
#define vcl_setiosflags vcl_generic_iomanip_STD :: setiosflags
#endif
// setbase
#ifndef vcl_setbase
#define vcl_setbase vcl_generic_iomanip_STD :: setbase
#endif
// setfill
#ifndef vcl_setfill
#define vcl_setfill vcl_generic_iomanip_STD :: setfill
#endif
// setprecision
#ifndef vcl_setprecision
#define vcl_setprecision vcl_generic_iomanip_STD :: setprecision
#endif
// setw
#ifndef vcl_setw
#define vcl_setw vcl_generic_iomanip_STD :: setw
#endif
// boolalpha
#ifndef vcl_boolalpha
#define vcl_boolalpha vcl_generic_iomanip_STD :: boolalpha
#endif
// noboolalpha
#ifndef vcl_noboolalpha
#define vcl_noboolalpha vcl_generic_iomanip_STD :: noboolalpha
#endif
// showbase
#ifndef vcl_showbase
#define vcl_showbase vcl_generic_iomanip_STD :: showbase
#endif
// noshowbase
#ifndef vcl_noshowbase
#define vcl_noshowbase vcl_generic_iomanip_STD :: noshowbase
#endif
// showpoint
#ifndef vcl_showpoint
#define vcl_showpoint vcl_generic_iomanip_STD :: showpoint
#endif
// noshowpoint
#ifndef vcl_noshowpoint
#define vcl_noshowpoint vcl_generic_iomanip_STD :: noshowpoint
#endif
// showpos
#ifndef vcl_showpos
#define vcl_showpos vcl_generic_iomanip_STD :: showpos
#endif
// noshowpos
#ifndef vcl_noshowpos
#define vcl_noshowpos vcl_generic_iomanip_STD :: noshowpos
#endif
// skipws
#ifndef vcl_skipws
#define vcl_skipws vcl_generic_iomanip_STD :: skipws
#endif
// noskipws
#ifndef vcl_noskipws
#define vcl_noskipws vcl_generic_iomanip_STD :: noskipws
#endif
// uppercase
#ifndef vcl_uppercase
#define vcl_uppercase vcl_generic_iomanip_STD :: uppercase
#endif
// nouppercase
#ifndef vcl_nouppercase
#define vcl_nouppercase vcl_generic_iomanip_STD :: nouppercase
#endif
// internal
#ifndef vcl_internal
#define vcl_internal vcl_generic_iomanip_STD :: internal
#endif
// left
#ifndef vcl_left
#define vcl_left vcl_generic_iomanip_STD :: left
#endif
// right
#ifndef vcl_right
#define vcl_right vcl_generic_iomanip_STD :: right
#endif
// dec
#ifndef vcl_dec
#define vcl_dec vcl_generic_iomanip_STD :: dec
#endif
// hex
#ifndef vcl_hex
#define vcl_hex vcl_generic_iomanip_STD :: hex
#endif
// oct
#ifndef vcl_oct
#define vcl_oct vcl_generic_iomanip_STD :: oct
#endif
// fixed
#ifndef vcl_fixed
#define vcl_fixed vcl_generic_iomanip_STD :: fixed
#endif
// scientific
#ifndef vcl_scientific
#define vcl_scientific vcl_generic_iomanip_STD :: scientific
#endif

#endif // vcl_generic_iomanip_h_
