#ifndef vcl_generic_exception_h_
#define vcl_generic_exception_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_exception.hhh and run make

// exception
#ifndef vcl_exception
#define vcl_exception vcl_generic_exception_STD :: exception
#endif
// bad_exception
#ifndef vcl_bad_exception
#define vcl_bad_exception vcl_generic_exception_STD :: bad_exception
#endif

#endif // vcl_generic_exception_h_
