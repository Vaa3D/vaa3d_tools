#ifndef vcl_generic_cerrno_h_
#define vcl_generic_cerrno_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_cerrno.hhh and run make


#endif // vcl_generic_cerrno_h_
