#ifndef vcl_generic_sstream_h_
#define vcl_generic_sstream_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_sstream.hhh and run make

// basic_stringbuf
#ifndef vcl_basic_stringbuf
#define vcl_basic_stringbuf vcl_generic_sstream_STD :: basic_stringbuf
#endif
// stringbuf
#ifndef vcl_stringbuf
#define vcl_stringbuf vcl_generic_sstream_STD :: stringbuf
#endif
// wstringbuf
#ifndef vcl_wstringbuf
#define vcl_wstringbuf vcl_generic_sstream_STD :: wstringbuf
#endif
// stringstream
#ifndef vcl_stringstream
#define vcl_stringstream vcl_generic_sstream_STD :: stringstream
#endif
// istringstream
#ifndef vcl_istringstream
#define vcl_istringstream vcl_generic_sstream_STD :: istringstream
#endif
// ostringstream
#ifndef vcl_ostringstream
#define vcl_ostringstream vcl_generic_sstream_STD :: ostringstream
#endif

#endif // vcl_generic_sstream_h_
