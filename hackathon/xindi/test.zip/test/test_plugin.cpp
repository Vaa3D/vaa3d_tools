/* test_plugin.cpp
 * This is a test plugin, you can use it as a demo.
 * 2012-01-01 : by YourName
 */
 
#include "v3d_message.h"
#include <vector>
#include "test_plugin.h"
#include "string"
#include "sstream"

using namespace std;
Q_EXPORT_PLUGIN2(test, TestPlugin);

void markers_singleChannel(V3DPluginCallback2 &callback, QWidget *parent);
template <class T> int pixel(T* data1d,
                              V3DLONG *dimNum,
                              int xc,int yc,int zc,int c,int rad);
template <class T> LandmarkList count(T* data1d,
                              V3DLONG *dimNum,
                             v3dhandle curwin,
                              int MarkAve, int MarkStDev, int rad, int c);


 
QStringList TestPlugin::menulist() const
{
	return QStringList() 
        <<tr("Single Channel Cell Counting")
        <<tr("DOES THIS WORK??")
		<<tr("about");
}

QStringList TestPlugin::funclist() const
{
	return QStringList()
		<<tr("func1")
		<<tr("func2")
		<<tr("help");
}

void TestPlugin::domenu(const QString &menu_name, V3DPluginCallback2 &callback, QWidget *parent)
{
    if (menu_name == tr("Single Channel Cell Counting"))
	{
        //v3d_msg("To be implemented?");
        markers_singleChannel(callback,parent);
	}
    else if (menu_name == tr("DOES THIS WORK??"))
	{
        v3d_msg("YES!!!!! There's just nothing here yet.");
	}
	else
	{
		v3d_msg(tr("This is a test plugin, you can use it as a demo.. "
			"Developed by YourName, 2012-01-01"));
	}
}


bool TestPlugin::dofunc(const QString & func_name, const V3DPluginArgList & input, V3DPluginArgList & output, V3DPluginCallback2 & callback,  QWidget * parent)
{
	vector<char*> infiles, inparas, outfiles;
	if(input.size() >= 1) infiles = *((vector<char*> *)input.at(0).p);
	if(input.size() >= 2) inparas = *((vector<char*> *)input.at(1).p);
	if(output.size() >= 1) outfiles = *((vector<char*> *)output.at(0).p);

	if (func_name == tr("func1"))
	{
		v3d_msg("To be implemented.");
	}
	else if (func_name == tr("func2"))
	{
		v3d_msg("To be implemented.");
	}
	else if (func_name == tr("help"))
	{
		v3d_msg("To be implemented.");
	}
	else return false;

	return true;
}



void markers_singleChannel(V3DPluginCallback2 &callback, QWidget *parent)
{
    v3dhandle curwin = callback.currentImageWindow();

    //cancels if no image
    if (!curwin)
    {
        v3d_msg("You don't have any image open in the main window.");
        return;
    }

    //if image, pulls the data
    Image4DSimple* p4DImage = callback.getImage(curwin); //the data of the image is in 4D (channel + 3D)

    unsigned char* data1d = p4DImage->getRawData(); //sets data into 1D array

    V3DLONG pages = p4DImage->getTotalUnitNumberPerChannel();
    //defining the dimensions
    V3DLONG N = p4DImage->getXDim();
    V3DLONG M = p4DImage->getYDim();
    V3DLONG P = p4DImage->getZDim();
    V3DLONG sc = p4DImage->getCDim();
    //input channel
    unsigned int c=1, rad=10;
    bool ok;
    if (sc==1)
        c=1; //if only using 1 channel
    else
        c = QInputDialog::getInteger(parent, "Channel", "Enter Channel Number", 1, 1, sc, 1,&ok);

    //storing the dimensions
    V3DLONG dimNum[4];
    dimNum[0]=N; dimNum[1]=M; dimNum[2]=P; dimNum[3]=sc;

    //pulling marker info
    int xc,yc,zc;
    LocationSimple tmpLocation(0,0,0);
    LandmarkList mlist = callback.getLandmark(curwin);
    QString imgname = callback.getImageName(curwin);
    int marknum = mlist.count();
    if (mlist.isEmpty())
    {
        v3d_msg(QString("The marker list of the current image [%1] is empty. Do nothing.").arg(imgname));
        return;
    }
    else
    {
        //radius input
        rad = QInputDialog::getInteger(parent, "Radius", "Enter radius", 1,1,P,1,&ok);

        //dynamic array to store average pixel values of all markers
        int * markAve;
        markAve = new int[marknum];
        int markSum = 0;

        //getting pixel values from each marker
        for (int i=0; i<marknum; i++)
        {
            tmpLocation = mlist.at(i);
            tmpLocation.getCoord(xc,yc,zc);
            int dataAve = pixel(data1d,dimNum,xc,yc,zc,c,rad);
            markAve[i] = dataAve;
            markSum += dataAve;
        }

        int MarkAve = markSum/marknum; //average pixel value of all markers in this channel
        //st dev of markAve
        int st=0;
        for (int i=0; i<marknum; i++)
        {
            int s = pow(markAve[i]-MarkAve,2.0);
            st += s;
        }
        int MarkStDev = sqrt(st/(marknum-1.0));

        //v3d_msg(QString("Mean value: %1. St Dev: %2").arg(MarkAve).arg(MarkStDev));

        //and here we need to add the function that will scan the rest of the image for other cells based on MarkAve and MarkStDev
        //int CellCnt = count(data1d,dimNum,curwin,MarkAve,MarkStDev,rad,c);
        //v3d_msg(QString("There are %1 cells in this channel").arg(CellCnt));

        LandmarkList newList = count(data1d,dimNum,curwin,MarkAve,MarkStDev,rad,c);
        LandmarkList& woot = newList;
        bool hi = callback.setLandmark(curwin,woot);

    }
    return;
}

//returns average pixel value in box of radius rad on channel c around a given marker
template <class T> int pixel(T* data1d,
                              V3DLONG *dimNum,
                              int xc,int yc,int zc,int c,int rad)
{
    V3DLONG N = dimNum[0];
    V3DLONG M = dimNum[1];
    V3DLONG P = dimNum[2];
    V3DLONG sc = dimNum[3];
    //1D data array stores in this order: C Z Y X
    V3DLONG shiftC = (c-1)*P*M*N;

    //defining limits
    V3DLONG xLow = xc-rad; if(xLow<0) xLow=0;
    V3DLONG xHigh = xc+rad; if(xHigh>N-1) xHigh=N-1;
    V3DLONG yLow = yc-rad; if(yLow<0) yLow=0;
    V3DLONG yHigh = yc+rad; if(yHigh>M-1) yHigh=M-1;
    V3DLONG zLow = zc-rad; if(zLow<0) zLow=0;
    V3DLONG zHigh = zc+rad; if(zHigh>P-1) zHigh=P-1;

    //scanning through the pixels
    V3DLONG k,j,i;
    int datatotal=0,runs=0;
    for (k = zLow; k < zHigh; k++)
    {
         V3DLONG shiftZ = k*M*N;
         for (j = yLow; j < yHigh; j++)
         {
             V3DLONG shiftY = j*N;
             for (i = xLow; i < xHigh; i++)
             {
                 int dataval = data1d[ shiftC + shiftZ + shiftY + i ];
                 datatotal += dataval;
                 runs++;
             }
         }
    }
    int dataAve = datatotal/runs;
    return dataAve;
}

//uses test data to scan and mark other cells
template <class T> LandmarkList count(T* data1d,
                              V3DLONG *dimNum,
                             v3dhandle curwin,
                              int MarkAve, int MarkStDev, int rad, int c)
{
    V3DLONG N = dimNum[0];
    V3DLONG M = dimNum[1];
    V3DLONG P = dimNum[2];
    V3DLONG sc = dimNum[3];
    //1D data array stores in this order: C Z Y X
    V3DLONG shiftC = (c-1)*P*M*N; //idk if I still need this here

    LocationSimple tmpLocation(0,0,0);
    LandmarkList newList;

    //we are going to segment by every half radius for accuracy (note this might cause overlap idk)
    int CellCnt=0;
    for (V3DLONG iz=rad/2; iz<P; iz+=rad/2)
    {
        V3DLONG shiftZ = iz*M*N;
        for (V3DLONG iy=rad/2; iy<M; iy+=rad/2)
        {
            V3DLONG shiftY = iy*N;
            for (V3DLONG ix=rad/2; ix<N; ix+=rad/2)
            {
                //(ix,iy,iz,c) are the coords that we are currently at
                //we throw these coords into func pixel to get the pixel value to compare to the training values
                int TempAve = pixel(data1d,dimNum,ix,iy,iz,c,rad);
                //we will say for now there is a cell if the test data is within 1/2 std of the training data
                if ( (TempAve>=MarkAve-MarkStDev/2) && (TempAve<=MarkAve+MarkStDev/2) )
                {
                    CellCnt++;
                 //insert function to place marker at coords (ix,iy,iz)
                    //C:\Users\Xinnamin\Documents\vaa3d_external\v3d_main\basic_c_fun I think
                    tmpLocation.x = ix;
                    tmpLocation.y = iy;
                    tmpLocation.z = iz;


                    newList.append(tmpLocation);

                }
            }
        }
    }
    //eventually want to return CellCnt and markers on image
    //note this function does not remember where the test data actually was, so it should find them again
    //return CellCnt;
    return newList;
}
